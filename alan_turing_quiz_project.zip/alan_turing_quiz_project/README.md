# Alan Turing Summary + Quiz Project
This project scrapes the Alan Turing Wikipedia page, summarizes it,
creates a quiz, and stores results in a SQLite DB.

## Setup
1. Run in Google Colab *or*
2. The DB file will appear in sample-data/.

## Files
- main.py – full script
- requirements.txt – dependencies
- sample-data/alan_turing_quiz.db – generated database
